import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/registration': {
        target: 'http://localhost:8080',
        changeOrigin: true,
      },
      '/update':
      {
        target:'http://localhost:8080',
        changeOrigin: true,
      },
      '/login': {
        target: 'http://localhost:8080',
        changeOrigin: true,
      },
      '/delete': {
        target: 'http://localhost:8080/delete/emailid',
        changeOrigin: true,
      }, 
       '/admin': {
        target: 'http://localhost:8080', 
        changeOrigin: true,
        secure: false,
      },
    }
  }
})
